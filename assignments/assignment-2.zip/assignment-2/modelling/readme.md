Modelleling

python script1.py > script1.log